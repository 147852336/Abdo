<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page title</title>
    <link rel="stylesheet" href="style/index.css">
    <script src="JavaScript/jquery.js"></script>
    <style>
         
          .msg{
            width: 100%;
            display: flex;      
            margin-bottom:0;       
            overflow: hidden;                      
        }  .me{            
            justify-content: flex-end;
            margin-bottom:0;
        }  .u{            
            justify-content: end-flex;
            margin-bottom:0;
        }  .msg p {
            padding: 6px;          
            margin: 5px;
            border-radius: 20px;
            max-width: 75%;
            white-space: pre-wrap;
            word-break: break-word;
            overflow: hidden;
            position: relative;
        }  .msg p span{
            font-size: 90%;
            color: #1539ff;
            right: -3px;
            width: 105%;
            background: #c0c0c0;            
            position: relative;
            bottom: -5px;
            align-items: center;
            justify-content: center;
            display: flex;
            left: -7px;
        }  .me p {
            background: #28ff00;              
        }  .u p{
            background: #848484;        
            color: #fff;    
            max-width: 80%;
        }  .imgbx{
            width: 40px;
            height: 40px;
            position: relative;
            border-radius: 50%;
            overflow: hidden;
            margin: 5px;
        }  .imgbx img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }  .msg img,  .msg video{
            width: 100%;
        }.typing{
            width: 50px;
            height: 50px;
            position: absolute;
        }
        
        
        /* style for bottom */
       .bottom{
            position: fixed;
            bottom: 0;
            width: 100%;
            min-height: 50px;
            background: #808080;       
            display: flex;
            align-items: center;
            justify-content: center;            
        }.bottom .bottom-info{
            position:relative;
            width: 100%;
            height: 100%;            
            display: flex;
            justify-content: space-around;
        }.bottom .bottom-info button {
            background: none;
            width: 40px;
            height: 40px;
            right: 2px;
            outline: none;
            border: none;
            position relative;
            overflow: hidden;
            display: none;      
            margin-bottom: 0;      
        }.bottom .bottom-info button.active {            
            display: block;
         }.bottom .bottom-info button img {            
            width: 80%;
            height: 80%;
            left: 0;
            top: 0;
        }.bottom .Share {
            display: flex;
            height: 50px;
            position: relative;
        }.bottom .Share .imgbx{
            width: 45px;height: 45px;
            position: relative;
        }.bottom .Share .imgbx img{
            width: 100%;
            height: 100%;
            position: absolute;
        }
        #myTextarea{
            resize: none;
            rows: 1;
            margin-bottom: 0px;
            max-height: 130px;            
            width: calc(100% - 45px);
            border: none;
            outline: none;
            background: none;
            font-size: 120%;
            padding: 3px;
            color: #ffffff;
        }#myTextarea::placeholder {
            color: #ffffff7f;
        }
  </style>
</head>
  dir="">
    <nav>
        <div class="date">
            <h2>STAF</h2>
            <div class="search">
                <input type="text" id="search">
             <img src="icon/search.png">
            </div>
            <div class="image-option">
                <img src="icon/flex-option.png">
            </div>
        </div>
        <div class="options">       
            <label id="p"> posts </label>      
            <label id="e"> exams </label>
            <label id="c"> chat </label>
        </div>
    </nav>
    <div class= ">      
                      
   </div>
      
    <?php
      include("activity/connect.php");
      
    ?>
    <script>
    function update(a) {     
         
        if(a == "posts") {
            $(document).ready(function () {
            $.ajax({           
                    url: "activity/posts.php",
                    type: "POST",
                    success:function (data) {
                      $(".body").html(data);  
                    }
                })  
            });  
        }else if(a == "chats") {
            $(document).ready(function () {
            $.ajax({           
                    url: "activity/massage.php",
                    type: "POST",
                    success:function (data) {
                      $(".body").html(data);  
                    }
                })  
            });  
      document.getElementById("c").classList.add("active");    
document.getElementById("p").classList.remove("active");
document.getElementById("e").classList.remove("active");            
        }else if(a == "exams") {
         $(document).ready(function () {
            $.ajax({           
                    url: "activity/exams.php",
                    type: "POST",
                    success:function (data) {
                      $(".body").html(data);  
                    }
                })  
            });   
        }                                                                                
                                                                                           
       }    
       update("chats");
       $("#p").click(function () {
          update("posts");        document.getElementById("p").classList.add("active");    
document.getElementById("e").classList.remove("active");
document.getElementById("c").classList.remove("active");      
       });
       $("#e").click(function () {
          update("exams");  
document.getElementById("e").classList.add("active");    
document.getElementById("p").classList.remove("active");
document.getElementById("c").classList.remove("active");      
       })
       $("#c").click(function () {
          update("chats");  
       })      
      function addlike(e) {
        var pid = document.getElementById(e).value;
        
           $.ajax({
               url: "activity/add_post.php",
               type: "POST",
               data:{
                   pid: pid
               },
               success:function () {
                update("posts")
               }
           })                                       
      }function profile(e) {
         alert(e.value);      
      }
    </script>
< >
</html>
