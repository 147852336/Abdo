  <?php
  include("connect.php");
  $get = $con->prepare("SELECT * FROM massges WHERE type = :type");
  $get->bindParam("type",$_SESSION["name"]->type);
  $get->execute();
  foreach($get AS $m){
      if($m["Uid"] == $_SESSION["name"]->ID) {
          $who = "me";
      }else {
          $who = "u";
      }
    $get2 = $con->prepare("SELECT * FROM users WHERE ID = :id");
    $get2->bindParam("id",$m["Uid"]);
    $get2->execute();
    foreach($get2 AS $pro){
       echo '<div class="msg '.$who.'">
     <p>'.$m["text"].'<span>'.$pro["name"].' · '.$m["date"].'</span></p>
        </div>';
    }
  }
  
?>
