<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
</head>
<body>
    <?php
$con = new PDO("mysql:host=localhost;dbname=sacf;charset=utf8","root","");
   session_start();  
   $nuser = $_SESSION["name"];
?>

</body>
</html>
