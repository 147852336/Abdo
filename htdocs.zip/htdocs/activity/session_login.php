if(isset($_POST["register"])){
 $check = $con->prepare("SELECT * FROM users WHERE number = :number ");
 $check->bindParam('number',$_POST['number']);
 $check->execute();
   if($check->rowCount()>0){
      echo '
        alert("الحساب مستحدم سابقا !");
    </script>';
    }else{
  $password = sha1($_POST['password']);
  
  $add = $con->prepare("INSERT INTO `users`(`name`, `number`, `password`, `photo`) VALUES (:name, :number, :password, 'profile.png')");
 $add->bindParam('name',$_POST['name']); 
 $add->bindParam('number',$_POST['number']);  
 $add->bindParam('password',$password);
 
 if($add->execute()) {
  echo '<p class="succeed">تم انشاء حساب بنجاح</p>';
 
  $get = $con->prepare("SELECT * FROM users WHERE number = :number");
  $get->bindParam('number',$_POST['number']);
  $get->execute();
  $user1 = $get->fetchObject();
  session_start();
  $_SESSION['name'] = $user1;
  header("location:../profile/update/index.php#personal");
 }else {
    echo '<p class="erro">حدث خطأ غير متوقع</p> <script>
        alert("حدث خطا غير متوقع");
    </script>';
 }}
 }
   ?>