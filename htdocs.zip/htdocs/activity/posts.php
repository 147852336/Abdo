<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>post</title>
    <link rel="stylesheet" href="../style/index.css">
    <script src="../JavaScript/jquery.js"></script>
    <script>
        
          function videos(h) {
          var g = document.getElementById(h);
              if(g.paused) {
                  g.play()
              }else {
                  g.pause()
              }          
           }
     
    </script>
</head>
<body>

 <?php
   include "connect.php";
   
   $get = $con->prepare("SELECT * FROM `posts`");
   $get->execute();
  foreach($get AS $posts){     
     
  
     $like = $con->prepare("SELECT * FROM `Plike` WHERE `Pid` = :id");
     $like->bindParam("id",$posts["ID"]);
     $like->execute();
     
     $likeM = $con->prepare("SELECT * FROM `Plike` WHERE `Pid` = :id AND `Uid` = :uid");
     $likeM->bindParam("id",$posts["ID"]);
     $likeM->bindParam("uid",$_SESSION["name"]->ID);
     $likeM->execute();         
     if($likeM->rowCount() == 1) {
         $active = 'color: #1539ff;background: #91ff7f';         
     }else {
         $active = "";
     }
     $get2 = $con->prepare("SELECT * FROM users  WHERE `ID` = :id");
     $get2->bindParam("id",$posts["Uid"]);
     $get2->execute();
     
   $text = $posts["text"]; 
   $pattern = '/\b(https?:\/\/\S+)\b/i'; 
   $replaced_text = preg_replace($pattern, '<a href="$1" target="_blank">$1</a>', $text);
     foreach($get2 AS $pro){     
     ?>
    <div class="post">     
       <div class="imgbx">
                <img src="http://localhost:8080/photo-profiles/<?php echo $pro["photo"] ?>" value="<?php echo $pro["ID"] ?>" onclick="profile(this.value)">
            </div>         
     <div class="post-info"> 
        <div class="head">       
          <div class="head-info">                       
            <div class="info">
                <h4><?php echo $pro["name"] ?></h4>
                <p><?php echo $posts["date"] ?></p>
            </div>     
          </div>             
            <div class="option">
                <img src="../icon/flex-option.png">
            </div>
        </div>                
        <div class="pbody">
            <div class="text">
         <p style="color:#fff;font-size:11r%;font-weight:700;white-space: pre-wrap;word-break: break-word; "><?php echo  $replaced_text ?></p>
            </div>                          
          <?php
          if($posts["video"] != "") {
          echo '<div class="file">
              <video src="http://localhost:8080/video/'.$posts["video"].'" id="'.$posts["ID"].'" controls></video></div>';    
          }else if ($posts["photo"] != "") {
          echo '<div class="file"><img src="http://localhost:8080/photo/'.$posts["photo"].'" /></div>';
          }
          ?>                                          
        </div>
        <hr>
        <div style="display: flex">
            <p> اعجاب <?php echo $like->rowCount() ?></p>
            <p>٠ 150 تعليق</p>
            <p>٠ 50 مشاركة</p>
        </div>
        <div class="bottom">                       
            <input type="button" value="<?php echo $posts["ID"] ?>" id="<?php echo $posts["ID"] ?>" onclick="addlike(this.id)">
           <label for="<?php echo $posts["ID"] ?>" style="<?php echo $active ?>">
                <span>like</span>
                <img src="icon/like.png" id="llike">
            </label>  
            <label for="comment">
                <span>comment</span>
                <img src="icon/comment.png">
            </label>
            <input type="button" id="comment">
            <label for="share">
                <span>share</span>
                <img src="icon/share.png">
            </label>
            <input type="button" id="share">
        </div>
    </div>
  </div>
     
    <?php
     }
   }
  ?>

    
</body>
</html>
