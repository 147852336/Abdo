<?php
 include("connect.php");
 $get = $con->prepare("SELECT * FROM friends WHERE Pid = :id OR Uid = :id ORDER BY date DESC");
 $get->bindParam("id", $_SESSION["name"]->ID);
 $get->execute();
 if($get->rowCount() == 0) {
     echo '<h1 style="display:flex;align-items:center;justify-content:center;height:100vh;margin:0;padding:0;">no chat here yet</h1>';
 }else {
  foreach($get AS $m){
     if($pro["Pid"] == $_SESSION["name"]->ID) {
         $id = $m["Uid"];
     }else {
         $id = $m["Pid"];
     }
    $get2 = $con->prepare("SELECT * FROM users WHERE ID = :id"); 
    $get2->bindParam("id",$id);
    $get2->execute();    
    foreach($get2 AS $pro){
        echo '       
         <div class="chat" id="'.$m["ID_room"].'">
            <div class="person">
              <div class="info">  
                <div class="imgbx">
                    <img src="photo-profiles/'.$pro["photo"].'" >
                </div>                
                    <div class="name">
                        <h2>'.$pro["name"].'</h2>
                        <p>'.$m["text"].'</p>
                    </div>
                </div>    
                    <div class="options">
                        <div class="imgbx">
                            <img src="icon/flex-option.png">
                        </div>
                        <div class="massage"></div>
                    </div>                
            </div>            
        </div>
       
        ';
    }
 }
}
?>
