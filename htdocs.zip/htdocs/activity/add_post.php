<?php
     include("connect.php");
     
     $pid = $_POST["pid"];
  if(isset($_POST["pid"])) {  
  $check = $con->prepare("SELECT * FROM Plike WHERE Uid = :id AND Pid = '$pid'");
   $check->bindParam("id",$_SESSION["name"]->ID);
   $check->execute();
   if($check->rowCount() == 0) {
   $addlike = $con->prepare("INSERT INTO Plike(Pid, Uid) VALUES ('$pid', :id)");
   $addlike->bindParam("id",$_SESSION["name"]->ID);
   $addlike->execute();  
   }else if($check->rowCount() == 1){
    
   $removelike = $con->prepare("DELETE FROM `Plike` WHERE `Uid` = :id AND `Pid` = '$pid'");
   $removelike->bindParam("id",$_SESSION["name"]->ID);
   if($removelike->execute()) {
       echo '<script>alert("ok");</script>';
   }else {
       echo '<script>alert("no");</script>';
   }  
   }
  
 }  
?>
