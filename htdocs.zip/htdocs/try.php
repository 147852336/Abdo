<?php
  

echo $replaced_text;

?>
