<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Home</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="style/login.css" />
  </head>
  <body>
  <?php if($_GET["type"] == "register"){ ?>
    <div class="container">
      <div class="center">
          <h1>Register</h1>
          <form method="POST">
              <div class="txt_field">
                  <input type="text" name="name" required>
                  <span></span>
                  <label>Name</label>
              </div>
              <div class="txt_field">
                  <input type="number" name="number" required>
                  <span></span>
                  <label>number</label>
              </div>
              <div class="txt_field">
                  <input type="password" name="password" required>
                  <span></span>
                  <label>Password</label>
              </div>
           
              <input name="register" type="Submit" value="Sign Up">
              <div class="signup_link">
                  Have an Account ? <a href="?type=">Login Here</a>
              </div>
          </form>
      </div>
  </div>
  <?php }else{ ?>
   <div class="container">
      <div class="center">
          <h1>Register</h1>
          <form method="POST">
             
              <div class="txt_field">
                  <input type="number" name="number" required>
                  <span></span>
                  <label>number</label>
              </div>
              <div class="txt_field">
                  <input type="password" name="password" required>
                  <span></span>
                  <label>Password</label>
              </div>
           
              <input name="login" type="Submit" value="Sign in">
              <div class="signup_link">
                 donot Have an Account ? <a href="?type=register">register Here</a>
              </div>
          </form>
      </div>
  </div>
  <?php } ?>
  
  <?php

  include("activity/connect.php");
    if(isset($_POST['login'])){
    $password = sha1($_POST['password']);
    $check = $con->prepare("SELECT * FROM users WHERE number = :number AND  password = :password");
    $check->bindParam('number',$_POST['number']);   
    $check->bindParam('password',$password);
    $check->execute();
   
    if($check->rowCount() == 1){
 $user = $check->fetchObject();      
session_start();
$_SESSION['name'] = $user;
header("location:../index.php");
}
else{
   echo '
<script>
alert("يرجي التاكد من البينات ( البينات التي تم ادخالها غير صحيحة)");
</script>  ';        
}
}



if(isset($_POST["register"])){
 $check = $con->prepare("SELECT * FROM users WHERE number = :number ");
 $check->bindParam('number',$_POST['number']);
 $check->execute();
   if($check->rowCount()>0){
      echo '
        alert("الحساب مستحدم سابقا !");
    </script>';
    }else{
  $password = sha1($_POST['password']);
  
  $add = $con->prepare("INSERT INTO `users`(`name`, `number`, `password`, `photo`) VALUES (:name, :number, :password, 'profile.png')");
 $add->bindParam('name',$_POST['name']); 
 $add->bindParam('number',$_POST['number']);  
 $add->bindParam('password',$password);
 
 if($add->execute()) {
  echo '<p class="succeed">تم انشاء حساب بنجاح</p>';
 
  $get = $con->prepare("SELECT * FROM users WHERE number = :number");
  $get->bindParam('number',$_POST['number']);
  $get->execute();
  $user1 = $get->fetchObject();
  session_start();
  $_SESSION['name'] = $user1;
  header("location:../profile/update/index.php#personal");
 }else {
    echo '<p class="erro">حدث خطأ غير متوقع</p> <script>
        alert("حدث خطا غير متوقع");
    </script>';
 }}
 }   
   
?>

  </body>
</html>
